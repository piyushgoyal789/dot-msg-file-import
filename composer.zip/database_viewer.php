<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MSG Database Viewer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
        h2 { color: #555; margin-top: 30px; }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .stat-card {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
            border-left: 4px solid #007bff;
        }
        .passenger-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        .passenger-card {
            background: #fff;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            padding: 15px;
        }
        .attachment-item {
            background: #f8f9fa;
            margin: 10px 0;
            padding: 10px;
            border-radius: 4px;
            border-left: 3px solid #28a745;
        }
        .filter-form {
            background: #e3f2fd;
            padding: 20px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        .base64-preview {
            background: #f1f3f4;
            padding: 8px;
            border-radius: 3px;
            font-family: monospace;
            font-size: 12px;
            max-height: 100px;
            overflow-y: auto;
            word-break: break-all;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        .btn {
            padding: 8px 16px;
            margin: 5px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
        }
        .btn-sm {
            padding: 4px 8px;
            font-size: 12px;
        }
        .btn-primary { background: #007bff; color: white; }
        .btn-primary:hover { background: #0056b3; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn-secondary:hover { background: #545b62; }
        .btn-success { background: #28a745; color: white; }
        .btn-success:hover { background: #1e7e34; }
    </style>
</head>
<body>
    <div class="container">
        <h1>MSG Database Viewer</h1>
        <a href="index.php" class="btn btn-secondary">← Back to MSG Parser</a>

<?php
require_once 'config.php';
require_once 'MsgDatabase.php';

function formatBytes($size, $precision = 2) {
    if ($size <= 0) return '0 B';
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    $base = log($size, 1024);
    return round(pow(1024, $base - floor($base)), $precision) . ' ' . $units[floor($base)];
}

try {
    $database = new MsgDatabase();
    
    // Handle search/filter
    $searchPassenger = $_GET['passenger'] ?? '';
    
    echo "<div class='filter-form'>";
    echo "<h3>Search & Filter</h3>";
    echo "<form method='GET'>";
    echo "<input type='text' name='passenger' placeholder='Search passenger name...' value='" . htmlspecialchars($searchPassenger) . "' style='padding: 8px; margin-right: 10px; width: 300px;'>";
    echo "<input type='submit' value='Search' class='btn btn-primary'>";
    if ($searchPassenger) {
        echo "<a href='database_viewer.php' class='btn btn-secondary'>Clear</a>";
    }
    echo "</form>";
    echo "</div>";
    
    // Display statistics
    $stats = $database->getAttachmentStats();
    echo "<h2>Database Statistics</h2>";
    echo "<div class='stats-grid'>";
    echo "<div class='stat-card'>";
    echo "<h4>Total Attachments</h4>";
    echo "<div style='font-size: 24px; font-weight: bold; color: #007bff;'>" . ($stats['total_attachments'] ?? 0) . "</div>";
    echo "</div>";
    echo "<div class='stat-card'>";
    echo "<h4>Unique Passengers</h4>";
    echo "<div style='font-size: 24px; font-weight: bold; color: #28a745;'>" . ($stats['unique_passengers'] ?? 0) . "</div>";
    echo "</div>";
    echo "<div class='stat-card'>";
    echo "<h4>Unique Emails</h4>";
    echo "<div style='font-size: 24px; font-weight: bold; color: #ffc107;'>" . ($stats['unique_emails'] ?? 0) . "</div>";
    echo "</div>";
    echo "<div class='stat-card'>";
    echo "<h4>Total Data Size</h4>";
    echo "<div style='font-size: 24px; font-weight: bold; color: #dc3545;'>" . formatBytes($stats['total_size'] ?? 0) . "</div>";
    echo "</div>";
    echo "</div>";
    
    // Get passenger attachments
    $attachments = $database->getPassengerAttachments($searchPassenger);
    
    if (!empty($attachments)) {
        echo "<h2>Passenger Attachments";
        if ($searchPassenger) {
            echo " - Filtered by: " . htmlspecialchars($searchPassenger);
        }
        echo " (" . count($attachments) . ")</h2>";
        
        echo "<table>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>Passenger Name</th>";
        echo "<th>Email Subject</th>";
        echo "<th>Email From</th>";
        echo "<th>Email Date</th>";
        echo "<th>Attachment</th>";
        echo "<th>Type</th>";
        echo "<th>Size</th>";
        echo "<th>Base64 Preview</th>";
        echo "<th>Actions</th>";
        echo "<th>Created</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        
        foreach ($attachments as $attachment) {
            echo "<tr>";
            echo "<td><strong>" . htmlspecialchars($attachment['passenger_name']) . "</strong></td>";
            echo "<td>" . htmlspecialchars($attachment['email_subject']) . "</td>";
            echo "<td>" . htmlspecialchars($attachment['email_from']) . "</td>";
            echo "<td>" . ($attachment['email_date'] ? date('Y-m-d H:i', strtotime($attachment['email_date'])) : 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($attachment['attachment_name']) . "</td>";
            echo "<td>";
            
            // Add file type icon
            $fileExt = strtolower(pathinfo($attachment['attachment_name'], PATHINFO_EXTENSION));
            $iconColor = '#6c757d';
            if ($fileExt === 'pdf') $iconColor = '#dc3545';
            elseif (in_array($fileExt, ['jpg', 'jpeg', 'png', 'gif'])) $iconColor = '#ffc107';
            elseif (in_array($fileExt, ['doc', 'docx'])) $iconColor = '#007bff';
            elseif (in_array($fileExt, ['xls', 'xlsx'])) $iconColor = '#28a745';
            
            echo "<span style='display: inline-block; width: 8px; height: 8px; background: $iconColor; border-radius: 50%; margin-right: 5px;'></span>";
            echo htmlspecialchars($attachment['attachment_type']);
            echo "</td>";
            echo "<td>" . formatBytes($attachment['attachment_size']) . "</td>";
            echo "<td>";
            if ($attachment['base64_preview']) {
                echo "<div class='base64-preview'>";
                echo htmlspecialchars(substr($attachment['base64_preview'], 0, 100)) . "...";
                echo "</div>";
                echo "<small>(" . strlen($attachment['attachment_data']) . " total chars)</small>";
            } else {
                echo "N/A";
            }
            echo "</td>";
            echo "<td>";
            
            // Add download button for PDFs and other files
            $fileExt = strtolower(pathinfo($attachment['attachment_name'], PATHINFO_EXTENSION));
            if (in_array($fileExt, ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png', 'gif', 'txt'])) {
                echo "<a href='download_attachment.php?id=" . $attachment['id'] . "' class='btn btn-success btn-sm' target='_blank'>";
                echo "📥 Download";
                echo "</a>";
            } else {
                echo "<span style='color: #6c757d; font-size: 12px;'>Not downloadable</span>";
            }
            echo "</td>";
            echo "<td>" . date('Y-m-d H:i', strtotime($attachment['created_at'])) . "</td>";
            echo "</tr>";
        }
        
        echo "</tbody>";
        echo "</table>";
        
    } else {
        echo "<h2>No Data Found</h2>";
        if ($searchPassenger) {
            echo "<p>No attachments found for passenger: <strong>" . htmlspecialchars($searchPassenger) . "</strong></p>";
        } else {
            echo "<p>No passenger attachment data in database. Upload and process MSG files first.</p>";
        }
    }
    
    // Display unique passenger names for quick access
    $allPassengers = $database->getPassengerNames();
    if (!empty($allPassengers)) {
        echo "<h2>Quick Access - Passengers</h2>";
        echo "<div style='margin: 20px 0;'>";
        foreach ($allPassengers as $passenger) {
            $isActive = $searchPassenger === $passenger;
            $btnClass = $isActive ? 'btn btn-primary' : 'btn btn-secondary';
            echo "<a href='?passenger=" . urlencode($passenger) . "' class='$btnClass'>";
            echo htmlspecialchars($passenger);
            echo "</a> ";
        }
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='color: red; padding: 20px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px;'>";
    echo "<strong>Database Error:</strong> " . htmlspecialchars($e->getMessage());
    echo "</div>";
}
?>

        <div style="margin-top: 40px; padding: 20px; background: #f8f9fa; border-radius: 6px;">
            <h3>Database Schema Information</h3>
            <p>The database stores passenger attachments with the following structure:</p>
            <ul>
                <li><strong>passenger_name:</strong> Extracted from attachment filename or content</li>
                <li><strong>email_subject:</strong> Subject line of the original email</li>
                <li><strong>email_from:</strong> Sender of the email</li>
                <li><strong>attachment_data:</strong> Full base64 encoded attachment data</li>
                <li><strong>base64_preview:</strong> First 500 characters for preview</li>
            </ul>
        </div>
    </div>
</body>
</html>