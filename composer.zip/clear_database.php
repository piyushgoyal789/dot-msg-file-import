<?php
require_once 'config.php';

try {
    $db = getDB();
    
    echo "Clearing database tables...\n";
    
    // Clear tables in correct order (due to foreign key constraints)
    $tables = ['email_passenger_attachments', 'passenger_attachments', 'emails'];
    
    $db->beginTransaction();
    
    foreach ($tables as $table) {
        $sql = "DELETE FROM $table";
        $stmt = $db->prepare($sql);
        $result = $stmt->execute();
        
        if ($result) {
            $rowCount = $stmt->rowCount();
            echo "✓ Cleared table '$table' - $rowCount rows deleted\n";
        } else {
            echo "✗ Failed to clear table '$table'\n";
            throw new Exception("Failed to clear table $table");
        }
    }
    
    // Reset auto-increment counters
    foreach ($tables as $table) {
        $sql = "ALTER TABLE $table AUTO_INCREMENT = 1";
        $stmt = $db->prepare($sql);
        $stmt->execute();
    }
    
    $db->commit();
    
    echo "\n🎉 Database successfully cleared!\n";
    echo "All tables are now empty and ready for new MSG file uploads.\n";
    
} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    echo "\n❌ Error clearing database: " . $e->getMessage() . "\n";
}
?>